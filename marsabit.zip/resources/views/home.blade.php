@extends('layouts.design')
@section('content')

@include('dashboardcontent')

@endsection