@extends('layouts.design')
@section('content')

@php 
  echo "Done Importing Data";
@endphp

@endsection